# ERS TypeScript client

This framework-neutral package provides:

- version 1 envelope parsing and validation;
- typed channel builders and parsing;
- connection lifecycle, reconnect, subscription-intent, deduplication, and recovery coordination;
- a provider-neutral Calls state machine for browser and application UI;
- presence and typing helpers; and
- standard WebSocket and HTTP adapters.

```ts
import { accountChannel, channelToString, parseEnvelope } from '@egensolve/realtime';

const channel = channelToString(
  accountChannel({ tenant: 'example', actorType: 'user', actorId: '42' }),
);

const envelope = parseEnvelope(receivedJson);
```

Application backends remain responsible for authenticating their users and deciding which
channels they may access. Never place installation credentials in browser or mobile clients.

## Media and Artifacts (trusted backends only)

Import `MediaClient` from `@egensolve/realtime/media`, `ArtifactsClient` from
`@egensolve/realtime/artifacts`, and HTTP response/error/transport types from
`@egensolve/realtime/http`. Construct either client with `baseUrl`, a server-held
`machineCredential`, and optionally an `ApiTransport` and `timeoutMs` (1000–30000).

Media supports upload intents, multipart part intents, completion, metadata, download grants and
deletion. Artifacts supports creation, revision upload/completion, publishing a ready revision and
withdrawal. Requests send version-1 JSON metadata, not file bytes. Your backend authorizes product
users and returns short-lived instructions for direct provider upload/download. Never embed a
machine credential in a browser, mobile app or widget; never log signed URLs or upload tokens.

Preserve returned IDs exactly, including letter case. Reuse an idempotency key only when retrying
the same mutation. Inspect `ApiResponse.data` for provider instructions and readiness; completion
acceptance alone does not imply readiness. Handle `ApiException.httpStatus` and `code`, and back
off on retryable failures. Publish an earlier ready revision to roll back an artifact.

## Calls

Use `initialCallProjection` and `reduceCall` from `@egensolve/realtime/calls` to drive a product's
custom call UI without exposing provider-specific objects. The reducer handles socket/push
invitation deduplication, canonical snapshot recovery, credential refresh ordering, group
participants, terminal races, bounded optional negotiation input, recording/intelligence states,
and logout cleanup. The product remains authoritative for caller identity, membership, ringing,
accept/decline/end decisions, and push delivery.

`CallsClient` is for trusted backends only. It creates and reads provider-neutral sessions, issues
short-lived join credentials, ends calls, and removes participants. Keep its machine credential on
the backend. A `recordable` call can expose recording and future intelligence progress; an
`e2ee_private` call deliberately disables server-side recording, transcription, and summaries.

Register `defineCallSurfaceElement()` from `@egensolve/realtime/calls/ui` for the optional Web UI.
Its useful default is customizable through semantic CSS properties, named shadow parts, content
slots, labels, and `ers-call-action` events while remaining independent of the RTC provider.

## License

MIT. See [LICENSE](LICENSE).

## Media retention and tiering

Trusted product backends can use `MediaClient.policy()` to discover effective retention limits and permitted tiering profile IDs. `updateRetention` accepts an explicit ISO-8601 expiry or authorized null expiry and an idempotency key. Upload intents may select a permitted `tiering_profile`. These endpoints require a server supporting configurable retention and the appropriate machine-credential abilities; null expiry does not extend upload or download capabilities.
