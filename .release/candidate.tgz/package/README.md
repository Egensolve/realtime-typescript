# ERS TypeScript client

This framework-neutral package provides:

- version 1 envelope parsing and validation;
- typed channel builders and parsing;
- connection lifecycle, reconnect, subscription-intent, deduplication, and recovery coordination;
- presence and typing helpers; and
- standard WebSocket and HTTP adapters.

```ts
import { accountChannel, channelToString, parseEnvelope } from '@egensolve/realtime';

const channel = channelToString(
  accountChannel({ tenant: 'example', actorType: 'user', actorId: '42' }),
);

const envelope = parseEnvelope(receivedJson);
```

Application backends remain responsible for authenticating their users and deciding which
channels they may access. Never place installation credentials in browser or mobile clients.

## Media and Artifacts (trusted backends only)

Import `MediaClient` from `@egensolve/realtime/media`, `ArtifactsClient` from
`@egensolve/realtime/artifacts`, and HTTP response/error/transport types from
`@egensolve/realtime/http`. Construct either client with `baseUrl`, a server-held
`machineCredential`, and optionally an `ApiTransport` and `timeoutMs` (1000–30000).

Media supports upload intents, multipart part intents, completion, metadata, download grants and
deletion. Artifacts supports creation, revision upload/completion, publishing a ready revision and
withdrawal. Requests send version-1 JSON metadata, not file bytes. Your backend authorizes product
users and returns short-lived instructions for direct provider upload/download. Never embed a
machine credential in a browser, mobile app or widget; never log signed URLs or upload tokens.

Preserve returned IDs exactly, including letter case. Reuse an idempotency key only when retrying
the same mutation. Inspect `ApiResponse.data` for provider instructions and readiness; completion
acceptance alone does not imply readiness. Handle `ApiException.httpStatus` and `code`, and back
off on retryable failures. Publish an earlier ready revision to roll back an artifact.

## License

MIT. See [LICENSE](LICENSE).
