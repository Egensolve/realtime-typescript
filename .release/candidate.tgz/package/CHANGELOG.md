# Changelog

## 0.2.0

- License this public package under MIT.
- Add trusted-backend Media and Artifacts entrypoints and bounded HTTP support.
- Preserve server-returned identifiers in their original case.
- Ship only the documented consumer surface, without source or declaration maps.

## 0.1.2

- Provide public envelope, channel, lifecycle, recovery, presence, typing, and adapter APIs.
- Exclude private administrative and asset-management clients from the public artifact.
