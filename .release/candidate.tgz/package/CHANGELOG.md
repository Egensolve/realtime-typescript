# Changelog

## 0.2.1

- Discover effective Media retention and permitted tiering profiles.
- Update per-asset retention with explicit finite expiry or authorized null expiry.
- Support the retention PATCH request while preserving metadata-only transfers.

## 0.2.0

- License this public package under MIT.
- Add trusted-backend Media and Artifacts entrypoints and bounded HTTP support.
- Add the provider-neutral trusted-backend Calls client and headless client state machine.
- Add the customizable, provider-neutral Calls Web Component foundation.
- Preserve server-returned identifiers in their original case.
- Ship only the documented consumer surface, without source or declaration maps.

## 0.1.2

- Provide public envelope, channel, lifecycle, recovery, presence, typing, and adapter APIs.
- Exclude private administrative and asset-management clients from the public artifact.
